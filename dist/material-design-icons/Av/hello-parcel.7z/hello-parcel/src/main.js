import React from 'react';
import { render } from 'react-dom';
import App from './App';

import './all.css';

render(<App name="Ryan" />, document.querySelector('#app'));
